﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace RTS_Gade_Home_
{
    class GameEngine
    {
        
       
        private Map mapHandle;
        private static int rounds;
        //private frmGame form;
        Random rng = new Random();

        
        public Map MapHandle { get => mapHandle; set => mapHandle = value; }
        public static int Rounds { get => rounds; set => rounds = value; }
        

        public string GameUpdater()
        {
            Unit tempUnit;
            MeleeUnit tempMUnit;
            RangedUnit tempRUnit;
            int unitsLeft;
            string unitInfo;            
            int faction;
            unitInfo = "";
            unitsLeft = Map.UnitsOnField.Length;
            for (int i = 0; i < unitsLeft; i++)//For each unit
            {                
                tempUnit = Map.UnitsOnField[i]; //Melee               
                if (tempUnit.ToString() == "Melee Unit")
                {
                    tempMUnit = (MeleeUnit)tempUnit;
                    faction = tempMUnit.Faction;
                    double percHP = (double)tempMUnit.Hp/tempMUnit.MaxHP * 100;
                    if (percHP < 25 & percHP> 0)
                    {
                        tempMUnit.Attacking = false;
                        tempMUnit.Move(0, i);
                        unitInfo += tempMUnit.Shape + " | HP:" + tempMUnit.Hp + " | Fleeing | " + "Team " + tempMUnit.Faction + " " + tempMUnit.ToString() + "\n";
                    }
                    else if (tempMUnit.Hp <= 0)
                    {
                        tempMUnit.Death(i);
                       
                    }
                    else //if not dead or fleeing, find enemy
                    {
                        
                        tempMUnit.FindEnemy(i);
                        unitInfo += tempMUnit.Shape + " | HP:" + tempMUnit.Hp + " | Hunting | "  + "Team " + tempMUnit.Faction + " " + tempMUnit.ToString() + "\n";
                    }

                    
                }
                else //Ranged
                {
                    tempRUnit = (RangedUnit)tempUnit;
                    faction = tempRUnit.Faction;
                    double percHP = (double)tempRUnit.Hp / tempRUnit.MaxHP * 100;
                    if (percHP < 25 & percHP > 0)
                    {
                        tempRUnit.Attacking = false;
                        tempRUnit.Move(0,i);
                        unitInfo += tempRUnit.Shape + " | HP:" + tempRUnit.Hp + " | Fleeing " + "Team " + tempRUnit.Faction + " " + tempRUnit.ToString() + "\n";
                    }
                    else if (tempRUnit.Hp <= 0)
                    {
                        tempRUnit.Death(i);
                        
                    }
                    else
                    {
                        
                        tempRUnit.FindEnemy(i);
                        unitInfo += tempRUnit.Shape + " | HP:" + tempRUnit.Hp + " | Hunting " + "Team " + tempRUnit.Faction +" "+ tempRUnit.ToString() + "\n"; 
                    }

                    
                }
                
            }
            rounds = rounds + 1;//Update rounds
            return unitInfo;//Return string for all units
        }

       
    }
}
