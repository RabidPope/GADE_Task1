﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RTS_Gade_Home_
{
    class Map
    {
        protected static Unit[] unitsOnField;
        protected int armySize;
        protected char[,] mapSymbols;
        protected Random rng = new Random();
        
        protected int mapSize;
        protected char [,] unitSymbols = { { 'X', 'V' },{ 'M', 'N' } };

        public Map(int armySize, int mapSize)
        {
            this.armySize = armySize;
            this.mapSize = mapSize;
            InitialiseMap();
        }

        public static Unit[] UnitsOnField { get => unitsOnField; set => unitsOnField = value; }

        public void InitialiseMap()
        {
            mapSymbols = new char[mapSize, mapSize];
            for (int x = 0; x < mapSize; x++)
            {
                for (int y = 0; y< mapSize; y++)
                {
                    mapSymbols[y, x] = '.';
                }
            }            
        }

        public void SpawnUnits()
        {
            int type;
            int xRoll;
            int yRoll;
            UnitsOnField = new Unit[armySize];
            int unitCount = 0;

                for (int unitPlaced = 0; unitPlaced < armySize; unitPlaced++)
                {
                    xRoll = rng.Next(0, mapSize);
                    yRoll = rng.Next(0, mapSize);

                    if (mapSymbols[yRoll, xRoll] == '.')//Use 2d symbols to determine open positions
                    {
                    int team = rng.Next(0, 2);
                        type = rng.Next(0, 2);
                        mapSymbols[yRoll, xRoll] = unitSymbols[team, type];

                        if (type == 0)
                        {
                            UnitsOnField[unitCount] = new MeleeUnit(xRoll, yRoll, team, unitSymbols[team, type], false);
                            unitCount++;
                        }
                        else
                        {
                            UnitsOnField[unitCount] = new RangedUnit(xRoll, yRoll, team, unitSymbols[team, type], false);
                            unitCount++;
                        }
                    }
                    else
                    {
                    unitPlaced--;//No open position, redo
                    }
                }
            
        }

        public string UpdateMap()
        {
            //variables
            string map = "";
            Unit tempUnit;
            MeleeUnit tempMUnit;
            RangedUnit tempRUnit;
            
            //Clean map so old unit symbols are removed
            InitialiseMap();
            
            //Re-fill mapSymbols array
            for (int i = 0; i < unitsOnField.Length; i++)
            {
                tempUnit = unitsOnField[i];
                if (tempUnit.ToString() == "Melee Unit")
                {
                    
                    tempMUnit = (MeleeUnit)tempUnit;
                    if (tempMUnit.Hp > 0)
                    {
                        mapSymbols[tempMUnit.YPos, tempMUnit.XPos] = tempMUnit.Shape;
                    }
                }
                else
                {
                    tempRUnit = (RangedUnit)tempUnit;
                    if (tempRUnit.Hp > 0)
                    {
                        mapSymbols[tempRUnit.YPos, tempRUnit.XPos] = tempRUnit.Shape;
                    }
                }
            }

            //Convert mapSymbols array to a string
            for (int x = 0; x < mapSize; x++)
            {
                for (int y = 0; y < mapSize; y++)
                {
                    map += mapSymbols[y, x];
                }
                map += "\n";
                 
            }
            return map;
        }
    }
}
