﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RTS_Gade_Home_
{
    abstract class Unit
    {
        
        protected int xPos;
        protected int yPos;
        protected int hp;
        protected int maxHP;
        protected int speed;
        protected int attack;
        protected int range;
        protected int faction;
        protected char shape;
        protected bool attacking;

        public Unit(int xPos, int yPos, int hp, int speed, int attack, int range, int faction, char shape, bool attacking)
        {
            this.xPos = xPos;
            this.yPos = yPos;
            this.hp = hp;
            this.maxHP = hp;
            this.speed = speed;
            this.attack = attack;
            this.range = range;
            this.faction = faction;
            this.shape = shape;
            this.attacking = attacking;
        }

        public abstract void Move(int index, int ownIndex);
        public abstract void Engage(int index);
        public abstract bool CheckRange(int range);
        public abstract void FindEnemy(int ownIndex);
        public abstract void Death(int index);
        public abstract override string ToString();
        

    }

    class MeleeUnit : Unit
    {

        
        public MeleeUnit(int xPos, int yPos, int faction, char shape, bool attacking) : base (xPos, yPos, 40, 1, 2, 1, faction, shape, attacking)
        {
            base.xPos = xPos;
            base.yPos = yPos;
            base.hp = hp;
            //base.maxHP = maxHP;
            base.speed = speed;
            base.attack = attack;
            base.range = range;
            base.faction = faction;
            base.shape = shape;
            base.attacking = attacking;
        }

        public int XPos { get => xPos; set => xPos = value; }
        public int YPos { get => yPos; set => yPos = value; }
        public int Hp { get => hp; set => hp = value; }
        public int MaxHP { get => maxHP;}
        public int Speed { get => speed; set => speed = value; }
        public int Attack { get => attack; set => attack = value; }
        public int Range { get => range; set => range = value; }
        public int Faction { get => faction; set => faction = value; }
        public char Shape { get => shape; set => shape = value; }
        public bool Attacking { get => attacking; set => attacking = value; }

        public override void Move(int index, int ownIndex)
        {
            MeleeUnit tempMUnit;
            RangedUnit tempRUnit;
            Random rng = new Random();

            if (GameEngine.Rounds % base.speed == 0)
            {

                if (Map.UnitsOnField[index].ToString() == "Melee Unit")
                {
                    double percHP = (double)base.hp / base.maxHP * 100;
                    if (percHP > 25)//Hunt
                    {
                        tempMUnit = (MeleeUnit)Map.UnitsOnField[index];
                        base.yPos = base.yPos + (Math.Max(-1, Math.Min(tempMUnit.YPos - base.yPos, 1)));
                        base.xPos = base.xPos + (Math.Max(-1, Math.Min(tempMUnit.XPos - base.xPos, 1)));
                    }
                    else//Flee
                    {
                        base.yPos = Math.Max(0, Math.Min(19, base.yPos + rng.Next(-1, 2)));
                        base.xPos = Math.Max(0, Math.Min(19, base.xPos + rng.Next(-1, 2)));
                    }
                }
                else
                {
                    double percHP = (double)base.hp / base.maxHP * 100;
                    if (percHP > 25)//Hunt//Hunt
                    {
                        tempRUnit = (RangedUnit)Map.UnitsOnField[index];
                        base.yPos = base.yPos + (Math.Max(-1, Math.Min(tempRUnit.YPos - base.yPos, 1)));
                        base.xPos = base.xPos + (Math.Max(-1, Math.Min(tempRUnit.XPos - base.xPos, 1)));
                    }
                    else//Flee
                    {
                        base.yPos = Math.Max(0, Math.Min(19, base.yPos + rng.Next(-1, 2)));
                        base.xPos = Math.Max(0, Math.Min(19, base.xPos + rng.Next(-1, 2)));
                    }
                }
                Map.UnitsOnField[ownIndex] = this;
            }
        }

        public override void Engage(int index)
        {
            MeleeUnit tempMUnit;
            RangedUnit tempRUnit;
            
            if (Map.UnitsOnField[index].ToString() == "Melee Unit")
            {
                tempMUnit = (MeleeUnit)Map.UnitsOnField[index];
                tempMUnit.Hp = tempMUnit.Hp - base.attack;
                Map.UnitsOnField[index] = tempMUnit;
            }
            else
            {
                tempRUnit = (RangedUnit)Map.UnitsOnField[index];
                tempRUnit.Hp = tempRUnit.Hp - base.attack;
                Map.UnitsOnField[index] = tempRUnit;
            }
            
        }

        public override bool CheckRange(int range)
        {
            bool inRange = false;
            if (base.range >= range)
            {
                inRange = true;
            }
            return inRange;
        }

        public override void FindEnemy(int ownIndex)
        {
            MeleeUnit tempMUnit;
            RangedUnit tempRUnit;

            int indexOfNearest = 0;
            int nearest = 999;
            int[] positionOfNearest = new int[2];

            for (int i = 0; i < Map.UnitsOnField.Length; i++)
            {
                if (Map.UnitsOnField[i].ToString() == "Melee Unit")
                {
                    tempMUnit = (MeleeUnit)Map.UnitsOnField[i];
                    if (tempMUnit.Faction != base.faction)
                    {
                        int xDistance = Math.Abs(base.xPos - tempMUnit.XPos);
                        int yDistance = Math.Abs(base.yPos - tempMUnit.YPos);
                        double trueDistance = Math.Sqrt(Math.Pow(xDistance, 2) + Math.Pow(yDistance, 2));
                        int distance = (int)Math.Round(trueDistance, 0);
                        if (distance < nearest && tempMUnit.Hp >= 0)
                        {
                            nearest = distance;
                            indexOfNearest = i;
                            positionOfNearest[1] = tempMUnit.XPos;
                            positionOfNearest[0] = tempMUnit.YPos;
                        }
                    }
                }
                else
                {
                    tempRUnit = (RangedUnit)Map.UnitsOnField[i];
                    if (tempRUnit.Faction != base.faction)
                    {
                        int xDistance = Math.Abs(base.xPos - tempRUnit.XPos);
                        int yDistance = Math.Abs(base.yPos - tempRUnit.YPos);
                        double trueDistance = Math.Sqrt(Math.Pow(xDistance, 2) + Math.Pow(yDistance, 2));
                        int distance = (int)Math.Round(trueDistance, 0);
                        if (distance < nearest && tempRUnit.Hp >= 0)
                        {
                            nearest = distance;
                            indexOfNearest = i;

                        }
                    }
                }
            }
            if (CheckRange(nearest) == true)
            {
                Engage(indexOfNearest);
            }
            else
            {
                Move(indexOfNearest, ownIndex);
            }
        }

        public override void Death(int index)
        {
           
        }

        public override string ToString()
        {
            return "Melee Unit";
        }
    }

    class RangedUnit : Unit
    {


        public RangedUnit(int xPos, int yPos, int faction, char shape, bool attacking) : base(xPos, yPos, 25, 2, 2, 3, faction, shape, attacking)
        {
            base.xPos = xPos;
            base.yPos = yPos;            
            base.faction = faction;
            base.shape = shape;
            base.attacking = attacking;
        }

        public int XPos { get => xPos; set => xPos = value; }
        public int YPos { get => yPos; set => yPos = value; }
        public int Hp { get => hp; set => hp = value; }
        public int MaxHP { get => maxHP; }
        public int Speed { get => speed; set => speed = value; }
        public int Attack { get => attack; set => attack = value; }
        public int Range { get => range; set => range = value; }
        public int Faction { get => faction; set => faction = value; }
        public char Shape { get => shape; set => shape = value; }
        public bool Attacking { get => attacking; set => attacking = value; }

		public override void Move(int index, int ownIndex)
		{
            MeleeUnit tempMUnit;
            RangedUnit tempRUnit;
            Random rng = new Random();

            if (GameEngine.Rounds % base.speed == 0)
            {

                if (Map.UnitsOnField[index].ToString() == "Melee Unit")
                {
                    double percHP = (double)base.hp / base.maxHP * 100;
                    if (percHP > 25)//Hunt
                    {
                        tempMUnit = (MeleeUnit)Map.UnitsOnField[index];
                        base.yPos = base.yPos + (Math.Max(-1, Math.Min(tempMUnit.YPos - base.yPos, 1)));
                        base.xPos = base.xPos + (Math.Max(-1, Math.Min(tempMUnit.XPos - base.xPos, 1)));
                    }
                    else//Flee
                    {
                        base.yPos = Math.Max(0, Math.Min(19, base.yPos + rng.Next(-1, 2)));
                        base.xPos = Math.Max(0, Math.Min(19, base.xPos + rng.Next(-1, 2)));
                    }
                }
                else
                {
                    double percHP = (double)base.hp / base.maxHP * 100;
                    if (percHP > 25)//Hunt
                    {
                        tempRUnit = (RangedUnit)Map.UnitsOnField[index];
                        base.yPos = base.yPos + (Math.Max(-1, Math.Min(tempRUnit.YPos - base.yPos, 1)));
                        base.xPos = base.xPos + (Math.Max(-1, Math.Min(tempRUnit.XPos - base.xPos, 1)));
                    }
                    else//Flee
                    {
                        base.yPos = Math.Max(0, Math.Min(19, base.yPos + rng.Next(-1, 2)));
                        base.xPos = Math.Max(0, Math.Min(19, base.xPos + rng.Next(-1, 2)));
                    }
                }
                Map.UnitsOnField[ownIndex] = this;
            }
        }
        public override void Engage(int index)
        {
            MeleeUnit tempMUnit;
            RangedUnit tempRUnit;

            if (Map.UnitsOnField[index].ToString() == "Melee Unit")
            {
                tempMUnit = (MeleeUnit)Map.UnitsOnField[index];
                tempMUnit.Hp = tempMUnit.Hp - base.attack;
                Map.UnitsOnField[index] = tempMUnit;//Do damage to unit at index
            }
            else
            {
                tempRUnit = (RangedUnit)Map.UnitsOnField[index];
                tempRUnit.Hp = tempRUnit.Hp - base.attack;
                Map.UnitsOnField[index] = tempRUnit;// Do damage to unit at index
            }
        }
        public override bool CheckRange(int range)
        {
            bool inRange = false;
            if (base.range >= range)
            {
                inRange = true;
            }
            return inRange;
        }
        public override void FindEnemy(int ownIndex)
        {
            
            MeleeUnit tempMUnit;
            RangedUnit tempRUnit;

            int indexOfNearest = 0;
            int nearest = 999;
            int [] positionOfNearest = new int[2];

            for (int i = 0; i < Map.UnitsOnField.Length; i++)
            {
                if (Map.UnitsOnField[i].ToString() == "Melee Unit")
                {
                    tempMUnit = (MeleeUnit)Map.UnitsOnField[i];
                    if (tempMUnit.Faction != base.faction)
                    {
                        int xDistance = Math.Abs(base.xPos - tempMUnit.XPos);
                        int yDistance = Math.Abs(base.yPos - tempMUnit.YPos);
                        double trueDistance = Math.Sqrt(Math.Pow(xDistance, 2) + Math.Pow(yDistance, 2));
                        int distance = (int)Math.Round(trueDistance, 0);
                        if (distance < nearest && tempMUnit.Hp >= 0)
                        {
                            nearest = distance;
                            indexOfNearest = i;
                            positionOfNearest[1] = tempMUnit.XPos;
                            positionOfNearest[0] = tempMUnit.YPos;
                        }
                    }
                }
                else
                {
                    tempRUnit = (RangedUnit)Map.UnitsOnField[i];
                    if (tempRUnit.Faction != base.faction)
                    {
                        int xDistance = Math.Abs(base.xPos - tempRUnit.XPos);
                        int yDistance = Math.Abs(base.yPos - tempRUnit.YPos);
                        double trueDistance = Math.Sqrt(Math.Pow(xDistance, 2) + Math.Pow(yDistance, 2));
                        int distance = (int)Math.Round(trueDistance, 0);
                        if (distance < nearest && tempRUnit.Hp >= 0)
                        {
                            nearest = distance;
                            indexOfNearest = i;
                            
                        }
                    }
                }
            }
            if (CheckRange(nearest) == true)
            {
                Engage(indexOfNearest);
            }
            else
            {
                Move(indexOfNearest,ownIndex);
            }
                
        }
        public override void Death(int index)
        {
            
        }
        public override string ToString()
        {
            return "Ranged Unit";
        }
    }
}
