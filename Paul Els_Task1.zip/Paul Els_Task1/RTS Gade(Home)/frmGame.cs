﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace RTS_Gade_Home_
{
    public partial class frmGame : Form
    {

        private Map map;
        private GameEngine engine;

        public frmGame()
        {
            InitializeComponent();
        }
                
        public void InitialiseGame()//Called from start button event
        {
            engine = new GameEngine();//create GameEngine instance
            map = new Map(10, 20);//create Map instance

            GameEngine.Rounds = 0;//Reset rounds counter
            //Set up map
            map.InitialiseMap();
            map.SpawnUnits();

            tmrTimer.Enabled = true;//Start timer
            
        }

        public void GameLoop()
        {
            rtfUnitInfo.Text = engine.GameUpdater();
            lblRound.Text = "Round:" + GameEngine.Rounds;
            lblMap.Text = map.UpdateMap();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            InitialiseGame();
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            tmrTimer.Enabled = !tmrTimer.Enabled;//Pause Timer
        }        

        private void timerTick(object sender, EventArgs e)
        {
            GameLoop();//Execute game updates
        }

        
    }
}
